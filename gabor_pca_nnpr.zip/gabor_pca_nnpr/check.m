clc;clear;
img_path_list= dir(strcat('.\pictures\','*.png'));
img_num= length(img_path_list);
for i=1:img_num
    if_LuoTian_Writed(img_path_list(i).folder,img_path_list(i).name);
end
