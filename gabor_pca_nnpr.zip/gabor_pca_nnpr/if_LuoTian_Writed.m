function if_LuoTian_Writed(folder,name)

%     image_path = './pictures/Anonymous_6.png';
    
    Image = imread([folder,'\',name]);

    lambda = 2:1:8;         % wavelength �߶�

    % picture_one_total = zeros(10,length(lambda)*8);
    picture_one_each = zeros(length(lambda)*8,1);

    temp_total = zeros(8,112500);
    theta = 0:pi/8:pi;   % orientation ����
    show_img = 0; %��ʾͼ�� 0����ʾ 1��ʾ

    for j = 1:length(lambda)
%         disp(['wavelength:' num2str(lambda(j))]);
        %����gabor�˲���

        if show_img==1
            figure(j)
        end

    %         figure(j,'Name',['wavelength:',num2str(lambda(j))])
        %��������˲�
        Ig_cell = cell(1,length(theta));
        for k = 1:(length(theta)-1)
            g = gabor(lambda(j),theta(k));
            Ig_cell{1,k} = uint8(imgaborfilt(Image,g));
        end

        if show_img==1
             subplot(3,4,9);
            imshow(double(Image));title('original image');

            for k = 1:(length(theta)-1)
                subplot(3,4,k);
                imshow(Ig_cell{1,k});title(['gabor image, ' num2str(k) 'pi/8 degree']);
            end

            img_sum = Ig_cell{1,1};
            for k = 2:(length(theta)-1)
                img_sum = Ig_cell{1,k} + img_sum;
            end

            subplot(3,4,12);
            imshow(img_sum);title('gabor image sum');
        end

        %PCA��ά
        for k = 1:length(theta)-1
            temp_total(k,:) = reshape(double(Ig_cell{1,k}),1,[]);
        end

        res = fastPCA(temp_total,1);
        %��ȡ�������
        for k=1:8
            picture_one_each((j-1)*8+k) = res(k);
        end

    end

    picture_one_each= sort(picture_one_each,'descend');
    
    resolt_value = nnpr_ano_2021_12_8(picture_one_each);
    %fprintf(['���ֵ:',num2str(nnpr_ano_2021_12_8(picture_one_each)),''])
    if resolt_value<0.01
        fprintf(2,'\t��\t')
        fprintf(['[',num2str(name),']\t'])
        fprintf(2,'����LuoTianд��\n')
    elseif resolt_value<0.5
        fprintf(['\t?\t[',num2str(name),']\t'])
        fprintf(' �е������LuoTianд��\n')
    elseif resolt_value<0.99
        fprintf(['\t?\t[',num2str(name),']\t'])
        fprintf(' ��Ϊ������LuoTianд��\n')
    else
        fprintf(['\t��\t[',num2str(name),']\t'])
        fprintf('��LuoTianд��\n')
    end
end